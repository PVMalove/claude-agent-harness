# Harness Next — единая программа модернизации (Rust + Python)

Дата проектирования: 2026-10-20. Репозиторий: https://github.com/PVMalove/claude-agent-harness

# Executive summary — Harness Next

**Зафиксировано:** одна финальная архитектура и один production cutover; новые системные компоненты реализуются на Rust с первого коммита, а не сначала на Python с последующей переписью. Python сохраняет skills, policy, AI routing и lifecycle decisions. Rust владеет trusted execution supervisor, OCI, контрольными командами QA, transactional SQLite WAL operational state, процессами и recovery. Версионированный IPC и ownership matrix фиксируются до реализации. Допускаются вертикальные PR и contract tests, но без throwaway production implementations.

**Производительность:** на Developer — impacted/related tests, после ошибки — только failed node IDs или `pytest --lf` с изолированным кэшем, перед выходом — независимый full clean-room QA по финальному SHA. `--ff` не равен failed-only; clean-room ordered scenarios нельзя безопасно делить без явных зависимостей.

**Надёжность:** concurrency нескольких batch без глобального ожидания; QA-lane singleton; durable leases, crash reconciliation, idempotency после lost ACK, SIGKILL/host reboot и корректная классификация infra/code/unknown. Предотвращение циклов `rewind → risk → review → QA` (#781).

**Безопасность:** pinned image/plan digest, rootless Podman на Fedora с SELinux и Docker, Windows execution adapter; `minimal | standard | strict` hook profiles при `start-project` и `integrate-project` (safety никогда не ослабевает); change-impact enforcement вместо буквального копирования GateGuard; нет прямого Docker сокета или policy downgrade у worker. Настройки hooks не заменяют OS isolation.

**Статус GitHub:** #784 — новый целевой epic, а #634 #709 #774 #777 #778 #779 #781 — открытые issues, **реально дополнены** 20 октября 2026. #615 #756 #757 #758 #769 #780 закрыты, не переоткрывались. Specs/ADR в репозитории НЕ редактировались напрямую: сначала review и ADR согласование, затем PR в согласованной integration ветке.

## Непересматриваемое решение

**Одна целевая реализация, без промежуточных переписываний.** Python сохраняет AI routing, skills, DDD/workflow policy и presentation/CLI. **Rust с первого целевого коммита** реализует системный runtime, управление процессами и контейнерами, исполнение QA, durable operational ledger и crash recovery. SQLite WAL используется для транзакционного operational state; неизменяемые evidence и audit должны сохранить верифицируемую цепь целостности, формат/миграцию которых фиксирует ADR. Работа разбивается на интегрируемые вертикальные срезы, но ни один не вводит временную Python-реализацию нового Rust-компонента.

**Стабильные границы до реализации:** `ExecutionPlan`, `ExecutionReceipt`, `ExecutionOutcome`, `VerificationPlan`, `FailureDiagnosis`, `Lease`, `EvidenceManifest`, `ApprovedAccessPlan`; versioned Unix Domain Socket IPC на Linux, platform adapter для Windows; schema-version, idempotency keys, SHA-256 digest approval. Python никогда не пишет в новую SQLite базу runtime. Rust не принимает lifecycle/publish/approval решений: они остаются у Python coordinator, который вызывает Rust транзакционными командами через согласованный контракт. Единственный авторитетный writer каждой сущности и строго очерченная ownership-модель. Временная совместимость старых записей — migration adapter/read-only fallback, **не параллельный второй ledger writer**.

## Карта зависимостей (только реальные контрактные зависимости)

```mermaid
flowchart LR
  A[00. Grill + согласование ADR/схем] --> B[01. Rust workspace, IPC, контракт]
  A --> C[02. Verification plan, test selection, evidence schema]
  A --> D[03. Lifecycle invariants / #781]
  B --> E[04. SQLite WAL + migrator + audit]
  B --> F[05. Rust process & OCI supervisor]
  C --> G[06. Focused / failed-only / full verification]
  E --> H[07. Batch concurrency & QA lease / #774]
  F --> I[08. Hardened worker/QA containers / #634 #709]
  G --> I
  D --> H
  H --> J[09. Full system integration + chaos]
  I --> J
  J --> K[10. CI performance baseline + cutover]
```

## Канонические workstreams

| ID | Владелец / область | Связанные issues | Готовность и DoD |
|---|---|---|---|
| 00 | Проектирование единой архитектуры | новая spec/ADR | Схема IPC, версии контрактов, матрица state machines, rollback/migration, приёмочная матрица, декомпозиция до первого production-кода |
| 01 | Rust runtime framework | новая issue | Cargo workspace; Tokio; safe Rust; rustfmt/clippy; UDS server; structured version/errors; single durable operation identity; Fedora/Windows build adapters |
| 02 | Transactional operational ledger | #774 #777 #778 #779 | SQLite WAL, независимые batch transactions, честный QA singleton lease, audit verification и миграция без loss/двойной записи; аварийное восстановление после SIGKILL |
| 03 | Process/OCI Supervisor | #634 #709 | `launch`, `inspect`, `stop`, `reconcile`, graceful kill; PID identity + OCI labels; durable receipt; no duplicate startup; signals and cgroups/systemd integration where available |
| 04 | Execution isolation | #634 #709 | pinned image digest, least privileges, SELinux/rootless Podman, no Docker socket in agent sandbox; read-only checkout and writable temp; denied network by default |
| 05 | Test planner | #756 #757 #758 closed (do not reopen); NEW | Change-impact via `repo_map` and `related_tests`; focused/test-only full. Developer diagnostics `pytest --lf`; no claim of full pass from subset |
| 06 | Verification evidence & rerun | #709; NEW | Record each stage and pytest nodeid, junit, stdout/stderr, exit, durations, `not_run`; precise failed-only rerun until green, **fresh full QA for final candidate SHA** |
| 07 | Workflow invariants | #781 | Rewind→risk→review→QA cannot dead-end, idempotent retries, invariant validation when committing transaction |
| 08 | GateGuard-inspired impact preflight | NEW | Machine-checked import/callsites/critical paths; advisory by default; sensitive targets require justified facts; never trust LLM prose as security permission |
| 09 | CI / fault injection | NEW | Linux/Fedora SELinux rootless Podman, Ubuntu, Windows. SIGKILL, IPC loss, disk full, stale process, double dispatch, incompatible schema, negative network tests |

## Файлы, которые агент обязан изучить перед coding

`harness/orchestration/ledger/lifecycle.py`, `ledger_admin.py`, `ledger_ops.py`, `recovery_chain.py`, `qa_lane.py`, `workflow/recovery.py`, `workflow/risk.py`, `workflow/dispatch.py`, `workflow/batch.py`, `contract.py`, `core/config.py`, `runtime_access.py`, `container_executor.py` (в integration ветке), `harness/gate_runner/gate_runner.py`, `harness/repo_map/`, `scripts/verify.py`, `scripts/test_clean_room.py`, `scripts/verification/process.py`, `harness/orchestration.example.json`, `.github/workflows/verify.yml`, `tests/orchestration/test_qa_lane.py`, `test_ledger.py`, `test_ledger_lock_environment.py`, `test_retry_verification.py`, `test_verification_profiles.py`, `docs/adr/0003-orchestration-core.md`, `docs/adr/0018-container-executor.md` (integration branch), `skills/first-party/pvmalove/{grill-with-docs,to-spec,to-tickets,implement}/SKILL.md`.

## Проверки обязательных свойств

1. Один full-suite на финальный candidate SHA при штатном пути. Несколько focused прогонов в dev не повторяют full-suite.
2. После failure разработчик исполняет точный nodeid / pytest `--lf --lfnf=none`; затем impact suite. Только новый clean-room full gate обеспечивает release evidence.
3. `pytest --ff` **не** означает failed-only; `--lf` применяется только с постоянным workspace-scoped cache. `scripts/verify.py` сейчас отключает cacheprovider по умолчанию и `mypy` temp cache удаляет — решить в рамках единого planner.
4. `test_clean_room.py` имеет shared context и ordered scenarios; нельзя произвольно пропускать сцену без декомпозиции fixtures/dependencies.
5. Fork/kill coordinator, затем Rust recovery: операция не дублируется, чужой PID не убивается, чужой lease не снимается.
6. Два batch одновременно проходят запись без global lock; singleton QA gate остается сериализованным. Нет deadlocks при сбое.
7. Подтвержденные инфраструктурные ошибки не тратят developer retry. Неизвестные ошибки fail closed без подмены code failure.
8. Процессы внутри sandbox не получают доступ к привилегированному Rust socket. Сервер строго валидирует approval-bound план, digest, identity и ACL.
9. Все runtime write операции либо транзакционно применены, либо идемпотентно откатываются/reconcile; audit остаётся проверяемым.
10. Полный cutover происходит только после тестов совместимости со старыми batch/evidence и замеров базовой версии. Бэкенд новых компонентов с первого дня Rust, никаких временных Python реализаций.

## Проверенный журнал изменений GitHub issues

| Issue | Состояние на 2026-10-20 | Действие |
|---|---|---|
| #784 | открыт | Существующий umbrella epic содержит Rust-first и Runtime Hook Profiles |
| #634 | открыт | Добавлена архитектурная связь Rust/OCI/IPC и recovery без утраты первоначальных критериев |
| #709 | открыт | Дополнены QA execution evidence, typed outcomes, full-vs-targeted tests и crash reconciliation |
| #774 | открыт | Уточнён конечный SQLite WAL writer и миграция аудита |
| #777 | открыт | Добавлены проверки PID reuse, PID namespaces и lease fencing |
| #778 | открыт | Уточнены границы audit verification/caching при SQLite migration |
| #779 | открыт | Добавлены transactional batch concurrency и singleton QA требования |
| #781 | открыт | Расширены state machine invariants и восстановление after rewind |
| #615 #756 #757 #758 #769 #780 | закрыты | Не переоткрыты; рассматриваются как существующая база |

Изменение issues ≠ изменение specs/ADR в Git. ADR 0003 находится в `master`, ADR 0018 — в `integration/container-executor`. Требуются отдельные docs PR и прохождение встроенных approval gates `/to-spec` и `/to-tickets`.

## Диаграмма целевых границ и потока проверки

```mermaid
flowchart LR
  UI[CLI / Skills / Claude / Codex] --> PY[Python Policy Coordinator]
  PY -->|Versioned IPC + approval digest| RU[Rust Trusted Supervisor]
  RU --> DB[(SQLite WAL
Operational State)]
  RU --> AUD[(Immutable audit + evidence)]
  RU --> OCI[OCI / Process groups / Windows Job]
  PY --> PLAN[Impact + VerificationPlan]
  PLAN --> RU
  OCI --> DEV[Focused Developer Tests]
  OCI --> QA[Clean-room FULL QA on final SHA]
  DEV -->|failed nodeids| FIX[Developer fix]
  FIX --> PLAN
  QA -->|green attestation| RELEASE[Python Publish Decision]
```

## Диаграмма восстановления после сбоя

```mermaid
stateDiagram-v2
  [*] --> Approved
  Approved --> Running: approved plan + unique operation_id
  Running --> Finished: executed + immutable evidence
  Running --> Unknown: IPC loss / coordinator SIGKILL
  Unknown --> Running: reconcile live execution, same operation_id
  Unknown --> Finished: persisted receipt already committed
  Unknown --> Blocked: policy or environment not proved
  Running --> Stopping: cancellation / timeout
  Stopping --> Finished: process tree + OCI cleanup confirmed
  Finished --> [*]
```

## Последовательность git-интеграции

- Подготовить единый ADR и deterministic JSON schema в одном PR; заморозить контракты до распределённых задач.
- Использовать **одну целевую integration ветку** (`integration/harness-next-runtime`), куда сливаются вертикальные срезы Rust и Python adapters по неизменному контракту. Существующие ветки `integration/orchestration-ledger` и `integration/container-executor` предварительно сравнить; забрать принятые изменения без reset/force push.
- Текущие открытые issues дополняются разделом `Harness Next integration` без удаления acceptance criteria. Закрытые #756 #757 #758 #780 #615 #769 не переоткрываются.
- Точечные contract/compile/test PR допускаются; «без промежуточных этапов» = без временного production implementation и повторного переписывания одних компонент, **не** без code review и QA.

## Ключевые промпты (готовы к копированию)

### Prompt A — `/grill-with-docs` (использовать первым)

```text
/grill-with-docs
Работаем в PVMalove/claude-agent-harness. Прожарь и задокументируй ЕДИНУЮ, СРАЗУ ЦЕЛЕВУЮ архитектуру Harness Next. Инвариант: не допускаются промежуточные реализации новых компонентов на Python с последующей переписью на Rust. Python сохраняет policy / AI coordinator / skills / CLI; Rust сразу владеет execution supervisor, OCI process lifecycle, durable transactional SQLite WAL operational ledger, verification runner, crash recovery. Не перерабатывай runtime в Rust позже: проектируй окончательный API сейчас.
Изучи: ADR 0003, ADR 0018 в integration/container-executor, #634 #709 #774 #777 #778 #779 #781, scripts/verify.py, test_clean_room.py, qa_lane.py, gate_runner.py, repo_map и текущие verification_profiles/retry_verification. Отметь закрытые #756 #757 #758 #780.
Потребуй систематизированного ответа на: (1) единственного writer для batch/dispatch/lease/immutable evidence; (2) versioned IPC Unix socket / Windows adapter, backward compatibility and auth; (3) schema evolution & one-time migration; (4) process identity vs PID namespace, OCI cleanup; (5) bounded retries infra vs code; (6) SHA/plan/digest identity and idempotency; (7) full QA once for final candidate, developer focused tests, pytest failed nodeids + ordered clean-room scenarios; (8) cache correctness & staleness; (9) network, native approvals, SELinux; (10) deadlocks and guarantees of QA singleton; (11) disaster recovery; (12) CI Linux/Windows/Fedora fault injection.
Сформируй риск-матрицу, invariants, sequence diagrams, failure state table, rejected alternatives, initial target structure (`native/harness-runtime` Cargo workspace), interface schemas, spec and executable acceptance tests. До реализации выяви несовместимые требования и предложи аргументированные решения по умолчанию. Задавай только вопросы, требующие выбора бизнес-гарантий, которых нельзя обоснованно вывести из ADR/кода; все остальные решения принимай самостоятельно и фиксируй. Не меняй master, не создавай PR и не запускай implement до финализации документации.
```

### Prompt B — `/to-spec`

```text
/to-spec
Синтезируй из результатов grill и docs/tasks/Harness Next единый COMPLETE SPEC с контрактами Rust/Python, SQLite WAL, migrator, no-double-write, process/OCI supervisor, role-approved sandbox and deterministic execution, targeted dev tests, full clean-room QA gate, typed infra failures, idempotent recovery, throughput telemetry, multi-platform CI. Применяй шаблон оригинального first-party скилла; при несовместимых требованиях выведи alternative/recommendation. Принцип: не выпускать временную Python реализацию Rust-компонентов. Не создавать новую integration ветку на каждый срез; один target integration/harness-next-runtime, существующие ветки только источник готовых изменений. Уважай STOP-AND-ASK встроенного скилла для seam и имени integration ветки. После согласования публикуй эпик с `status::specs`, `type::feature`, `task-report::required` и связанных existing issue без дублирования.
```

### Prompt C — `/to-tickets`

```text
/to-tickets
Возьми Harness Next spec; выполни разбиение на независимые проверяемые tracer-bullet задачи с blocked-by ТОЛЬКО при реальной result dependency. Каждый тикет должен иметь existing/new status, конкретные функции и файлы, инварианты/стейт-транзишны/JSON schema, контракт входа/выхода, failure injection сценарий, инструменты тестирования, критерии приёмки, план мерджа. Rust во всех новых runtime компонентах сразу, Python только adapters/coordinator. Не создавать Python prototype. Не дублируй текущие #634/#709/#774/#777/#778/#779/#781 — модернизируй и линкуй их как части эпика. Существующие закрытые #756/#757/#758/#780 не открывать. Предложи срезы суммарно covering SQL migration, process supervisor, QA container, test planner, CI. Соблюди approval gate скилла до публикации.
```

### Prompt D — `/implement` для агента

```text
/implement
Реализуй согласованный Harness Next на базе утверждённых ADR/schema в интеграционной ветке; не допускается временная Python реализация новой Rust логики. Сначала прочитай точный immutable brief и его integration base; выполняй каждый тикет как production Rust implementation + integration tests, включая py client adapter. Cargo fmt/clippy/test; mypy, targeted pytest, failure nodeid rerun, clean-room full QA только при финальном candidate. Не запускай полный make verify на каждом dev/review исправлении. Не меняй approvals/allowed_tools/sandbox policy. Нет скрытых grants или fallback, при несовпадении версий IPC/Digest возвращай typed blocker. TDD, review Standards/Spec, независимый QA, immutable evidence. Завершай только с green approved candidate, report и PR к правильной integration ветке. Не делай rebase/force на чужих ветках.
```

### Prompt E — предварительные изменения существующих issues/specs

```text
Пройди открытые #634 #709 #774 #777 #778 #779 #781. Прочитай актуальные body и связанные ADR 0003/0018. Добавь раздел `Harness Next target architecture` с общей целевой границей: Rust с первого этапа является единственным process/OCI/runtime writer и SQLite operational-store writer, Python policy coordinator; миграция без dual write. Для #774 включи транзакционный batch concurrency, singleton QA lease, old-format migration, audit integrity и perf baselines; для #634/#709 — Rust ownership процесса/контейнера, pinned digest, hardening, status/stop/recovery, stage evidence и no Docker socket exposure; для #781 — invariant risk re-evaluation candidate and idempotency; для #777-779 — OS locks, audit and batch-scoped reads adapted to Rust SQLite design. Предыдущие acceptance, links и blocker правила НЕ удалять; если они прямо противоречат единой новой spec — пометить `Superseded-by-Harness-Next` с аргументом, не менять молча. Для открытых задач не создавать дубликаты. Публикацию делай только после сверки текущей ветки и конфликтов.
```

## Дополнение к единому target spec — Runtime Hook Profiles (включено в реализацию с первого release)

**Архитектурный принцип.** Профили `minimal | standard | strict` управляют поведенческими предупреждениями и pre-tool гейтами, но не заменяют и не могут отключать реальные границы OS sandbox, ACL Rust IPC, approvals и pinned dispatch. Один policy resolver и versioned `ApprovedHookPolicy` с `policy_digest`, закреплённым в immutable brief. Runtime enforce критичных запретов должен происходить в доверенном Rust boundary; Claude hooks и Codex adapters являются client-side дополнительными проверками, не единственным исполнителем защиты. Профиль нельзя менять через env переменную агента.

| Профиль | Поведение | Неизменяемые границы |
|---|---|---|
| `minimal` | Не блокировать за обычные style/impact reminders. Только жизненно важные проверки. | Secrets/credentials, branch ownership, destructive actions, approval and sandbox boundaries остаются включены |
| `standard` (новые проекты) | Критичные проверки + bounded first-touch change-impact evidence на рискованных файлах, предупреждения при отсутствии focused tests, дедупликация событий. | То же, плюс контролируемая диагностика |
| `strict` | Fail-closed на критичных паттернах: auth/permission/CI/migrations/secret/path traversal; машинно проверяемый impact evidence и аудит. | То же, причём explicit operator recovery имеет bounded procedure, не бесконечные DENY loops |

**Инсталляция и миграция.** `start-project` и `integrate-project` разрешают опциональную конфигурацию профиля и совместимые role/path overrides. Установка управляемых hooks повторяема без удаления чужих hooks. Старые проекты сохраняют наблюдаемую политику, если не выбран явный owner-approved переход; новые получают `standard`. `harness health` показывает effective policy, provenance, missing managed hooks, privileged runtime readiness и incompatible policy digest. При changed config уже созданный dispatch исполняется по исходному pinned digest, а новый план требует нового approval.

**DoD / тесты:** profile×role×sensitive path×tool matrix; changed hook profile after approval; symlink / hardlink bypass; missing unsafe secret; injected agent environment; nested Claude sandbox; recovery после hook failure; отсутствие циклических DENY и дублирования `make verify`; Linux/Windows; Codex и Claude adapter parity. В `strict` нельзя запускать все тесты после каждого Edit — планированием тестов владеет `VerificationPlan`.

**Проследить в issue:** https://github.com/PVMalove/claude-agent-harness/issues/784, карточки `HN-11`, `HN-12`, `HN-14` в интерактивной доске. Не откладывать hook profiles после Rust cutover и не писать временную Python policy-server реализацию.

### Дополнительный максимально подробный prompt для `/grill-with-docs`: профили хуков

```text
/grill-with-docs
Цель: в целевом Harness Next (#784) внедрить Native Runtime Hook Profiles minimal|standard|strict одновременно с Rust runtime, без временных Python server implementation и второго rewrite. Сначала открой код ветки master (harness/project/hooks/, harness/health/, harness/orchestration/contract.py, core/config.py, operational_guards.py), а также actual installation templates и скиллы start-project, integrate-project. Проверь Claude settings.json, Git safety hooks, Codex adapter и правила имени веток по исходникам — не придумывай пути.

Проработай конфигурацию, происхождение авторитетной политики, immutable policy digest и binding к dispatch, safe default и precedence (project owner/role/path/task) без agent-controlled downgrade. Предложи конечный wire schema для Rust PolicyDecision {hook_id, event_id, actor, role, profile, subject, policy_digest, decision, reason_code, evidence_refs, remediation}; explicit events and bounded retries. Не подменяй операционное approve утверждением LLM.

Защита должна гарантировать невозможность bypass через symlink/hardlink, filename case variants, shell argument quoting, env, hook failure, concurrent MultiEdit, malformed payload, native sandbox mismatch. Критические запреты не отключаются даже в minimal. Standard добавляет machine-derived repo_map change impact. Strict fail-closed только на релевантных высокорисковых границах, с аудируемым owner-only recovery без бесконечных блокировок. Полная тестовая матрица profile × role × path × tool × OS × runtime Claude/Codex. Никакого полного make verify после каждого Edit.

Изучи все существующие инварианты и схему установки, собери security threat model, архитектурные альтернативы и rejected options; сам выбери консервативные инженерные defaults, вопросы оставь только для решения владельца по несовместимым правилам безопасности. Сформируй ADR и spec-ready acceptance criteria до производства кода; соблюди правила встроенного grilling и approvals.
```

## Файлы проекта и страница управления

- `HARNESS_NEXT_PLANNER.html` — автономная Kanban-доска с 17 task cards, интерактивными зависимостями, подробными промптами и экспортом статусов в Markdown/JSON. Хранит состояние в `localStorage` текущего браузера; не синхронизирует статусы обратно в GitHub автоматически.
- `PLANNER_TASKS.json` — машиночитаемый список всех карточек и acceptance criteria, не авторитетный источник GitHub issue state.
- `ROADMAP.md` — данная архитектурная дорожная карта.
